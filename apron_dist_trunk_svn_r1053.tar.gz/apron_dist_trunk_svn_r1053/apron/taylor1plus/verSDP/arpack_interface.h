int arpackEig(int n, int nzn, double* elements, int* rIndices, int* cStarts, double* res, int mode);
